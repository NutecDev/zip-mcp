This zip was created with the zip-mcp compression utility.
